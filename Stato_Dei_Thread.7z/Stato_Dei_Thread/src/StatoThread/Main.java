package StatoThread;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		int t,n=0;
		
		System.out.println("Inserire il numero dei Thread e il numero massimo del contatore:");
		t=s.nextInt();
		n=s.nextInt();
		Thread [] threads =new Thread [t];
		for(int i = 0;i < t;i++) {
			threads[i] = new Thread(new Counter(n));
			threads[i].start();
		}
		
		
		while(true) {
			int h=0;
			for(int i = 0; i<t; i++) {
				if(threads[i].isAlive()) {
					System.out.println(threads[i]+" - Sta contando");
				}else {
					h++;
				}
				try {
					Thread.sleep(1000);
				}catch(InterruptedException c) {
			}
		}
			if(h==t) {
				System.out.println("TUTTI HANNO CONTATO");
				break;
			}
			
	}
		
		s.close();
		
	}
}
