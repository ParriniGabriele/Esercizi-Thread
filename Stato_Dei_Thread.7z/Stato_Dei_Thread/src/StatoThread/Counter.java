package StatoThread;
import java.util.Random;
import java.util.random.*;
public class Counter implements Runnable{
	Random r=new Random();
	int n;
	public Counter(int n) {
		this.n =n;
	}
	
	public void run() {
		int c=r.nextInt(n);
		for(int i=0;i<c;i++) {
			try {
				Thread.sleep(120);
				
			}catch(InterruptedException e) {
				
			}
			
		}
	System.out.println(Thread.currentThread().getName()+" HO CONTATO");
	}
	
}
