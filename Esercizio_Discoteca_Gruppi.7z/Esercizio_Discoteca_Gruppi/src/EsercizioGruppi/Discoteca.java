package EsercizioGruppi;
import java.util.Random;
import java.util.random.*;
public class Discoteca {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numeroGruppi=4;
		Random rand=new Random();
		Contatore cont = new Contatore();
		
		for(int i=0;i<numeroGruppi;i++) {
			int n=rand.nextInt((20)+1);
			new Thread(new Persone(n)).start();
			
		}
		while(true) {
			try {
				Thread.sleep(2000);
				System.out.println("Persone nella discoteca: "+cont.getPersone());
			}catch(InterruptedException e) {
				
			}
		}
	}

}
