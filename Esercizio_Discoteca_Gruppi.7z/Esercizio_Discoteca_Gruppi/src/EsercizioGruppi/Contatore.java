package EsercizioGruppi;
import java.util.Random;
public class Contatore {
	private static int numPersone=0;
	
	Random random = new Random();
	
	public void entra(int persone) {
		
		numPersone+=persone;
		System.out.println("Il Gruppo "+Thread.currentThread().getName()+" è entrato con "+persone+" persone.");
	}
	public void esce(int persone) {
		numPersone-=persone;
		System.out.println("Il Gruppo "+Thread.currentThread().getName()+" è uscito con "+persone+" persone.");
	}
	public int getPersone() {
		return numPersone;
	}
}
