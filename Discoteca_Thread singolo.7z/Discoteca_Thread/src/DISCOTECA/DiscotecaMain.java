package DISCOTECA;
import java.util.Random;

public class DiscotecaMain {
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numeroPersone=5;
		Persona persona=new Persona();
		ContTotale cont=new ContTotale();
		
		
		for(int i=0;i<numeroPersone;i++) {
			Thread pers=new Thread(new Persona());
			pers.start();
		}
		while(true) {
			try {
			Thread.sleep(1000);
			System.out.println("Persone in discoteca: "+cont.getPersone());
			}catch(InterruptedException e){
				e.printStackTrace();
				
			}
		}
		
		
		
	}

}
