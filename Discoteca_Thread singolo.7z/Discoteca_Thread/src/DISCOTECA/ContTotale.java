package DISCOTECA;

public class ContTotale {
private static int numeroPersone=0;

public synchronized void entra() {
	numeroPersone++;
	System.out.println(Thread.currentThread().getName()+" è entrato in discoteca");
}
public synchronized void esci() {
	numeroPersone--;
	System.out.println(Thread.currentThread().getName()+" è uscito dalla discoteca");
}
public int getPersone() {
	return numeroPersone;
}
}
