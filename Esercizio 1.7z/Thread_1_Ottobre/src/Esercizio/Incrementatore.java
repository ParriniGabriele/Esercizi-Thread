package Esercizio;

public class Incrementatore implements Runnable {
	private int limit;
	private Contatore c;
	public void setLimit(int l) {
		limit=l;
		
	}
	public Incrementatore(Contatore c,int limite) {
		this.c=c;
		this.limit=limite;
	}
	
	public void run() {
		while(true) {
			int valore = c.incrementa(limit);
		
		if(valore==-1)
			break;
		System.out.println(Thread.currentThread().getName()+" - "+valore);
		}
	}
}
