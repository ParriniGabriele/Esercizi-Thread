package Esercizio;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int t,n;
		Contatore c=new Contatore();
		Scanner input =new Scanner(System.in);
		
		
		
		System.out.println("Inserisci il numero di Thread da far operare:");
		t=input.nextInt();
		System.out.println("Inserisci il limite del contatore:");
		n=input.nextInt();
		
		
		for(int i=0;i<t;i++) {
			Thread T=new Thread(new Incrementatore(c,n));
			T.start();
		}
		
		
		
		
		
		
		
		
		
		
		input.close();
	}

}
