package Esercizio;

public class Contatore {
	int cont=0;
	
	
	
	
	public int incrementa(int limit) {
		if(cont<limit) {
			cont++;
		return cont;
		}else {
			return -1;
		}
		}
}
